import random

f = open('liste-poids-bias.txt', 'w')

# Poids 1 :

for i in range(783):
	for j in range(15):
		f.write(str((random.random() - 0.5) * 2) + ',')
	f.write(str((random.random() - 0.5) * 2) + ';')
for j in range(15):
	f.write(str((random.random() - 0.5) * 2) + ',')
f.write(str((random.random() - 0.5) * 2) + '\n')

# Poids 2 :

for i in range(15):
	for j in range(15):
		f.write(str((random.random() - 0.5) * 2) + ',')
	f.write(str((random.random() - 0.5) * 2) + ';')
for j in range(15):
	f.write(str((random.random() - 0.5) * 2) + ',')
f.write(str((random.random() - 0.5) * 2) + '\n')

# Poids 3 :

for i in range(15):
	for j in range(9):
		f.write(str((random.random() - 0.5) * 2) + ',')
	f.write(str((random.random() - 0.5) * 2) + ';')
for j in range(9):
	f.write(str((random.random() - 0.5) * 2) + ',')
f.write(str((random.random() - 0.5) * 2) + '\n')

# Bias 1 :

for i in range(15):
	f.write(str((random.random() - 0.5) * 2) + ',')
f.write(str((random.random() - 0.5) * 2) + '\n')

# Bias 2 :

for i in range(15):
	f.write(str((random.random() - 0.5) * 2) + ',')
f.write(str((random.random() - 0.5) * 2) + '\n')

# Bias 3 :

for i in range(9):
	f.write(str((random.random() - 0.5) * 2) + ',')
f.write(str((random.random() - 0.5) * 2))

f.close()