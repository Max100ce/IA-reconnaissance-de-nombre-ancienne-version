import pygame
from math import *
from tqdm import tqdm
import sys
from random import randint

# Ouverture des packs d'entrainements

f = open('pack d\'entrainement du MNIST/train-images.idx3-ubyte', 'rb')
f2 = open('pack d\'entrainement du MNIST/train-labels.idx1-ubyte', 'rb')
contenu = f.read()
contenu2 = f2.read()

data = []
image = []
ligne = []
for i in tqdm(range(16, len(contenu))):
	ligne.append(contenu[i])
	if (i - 16) % 28 == 27:
		image.append(ligne)
		ligne = []
	if (i - 16) % 784 == 783:
		data.append((image, contenu2[8 + (i - 16) // 784]))
		image = []

f.close()
f2.close()

# Réseau de neuronnes et calcul :
# 		- 784 neuronnes d'entrées : les 784 pixels
#		- 16 neuronnes cachés, premier layer
# 		- 16 neuronnes cachés, deuxième layer
# 		- 10 neuronnes de sortie, de 0 à 10

class Neuronne:
	def __init__(self, valeur, posX, posY):
		self.valeurAncienne, self.valeur = valeur, valeur
		self.posX, self.posY = posX, posY

class Liaison:
	def __init__(self, valeur, posX, posY1, posY2):
		self.valeurAncienne, self.valeur = valeur, valeur
		self.posX, self.posY1, self.posY2 = posX, posY1, posY2

def neuronneEntre(image):
	listeNeuronneEntree = []
	for i in range(len(image[0])):
		for j in range(len(image[0][i])):
			listeNeuronneEntree.append(image[0][i][j] / 255)
	return listeNeuronneEntree

def sinusoide(valeur):
	if valeur <= -709:
		valeur = -708
	return 1 / (1 + exp(-valeur))

def multiplieMatrice(matrice, poids, bias):
	matriceSortie = []
	for i in range(len(bias)):
		valeur = bias[i].valeur
		for j in range(len(poids)):
			valeur += matrice[j] * poids[j][i].valeur
		matriceSortie.append(sinusoide(valeur))
	return matriceSortie

def calculeCout(listeSortie, listeVoulue):
	assert len(listeSortie) == len(listeVoulue), 'Bh ouais y a une erreur ' + str(len(listeSortie)) + ' et ' + str(len(listeVoulue))
	cout = 0
	for i in range(len(listeSortie)):
		cout += pow(listeSortie[i] - listeVoulue[i], 2)
	return cout

def calcluleStat(cout, tente, reussi, listeSortie, listeVoulue):
	cout += calculeCout(listeSortie, listeVoulue)
	tente += 1
	maxi = (listeSortie[0], 0)
	for i in range(len(listeSortie)):
		if listeSortie[i] > maxi[0]:
			maxi = (listeSortie[i], i)
	if listeVoulue[maxi[1]] == 1:
		reussi += 1
	return cout, tente, reussi

# Amélioration du réseau de neuronne

def sinusoideDerivee(valeur):
	if valeur <= -354:
		valeur = -353
	return exp(-valeur) / pow(1 + exp(-valeur), 2)

def inverseSinusoide(valeur):
	if valeur >= 1:
		valeur = 1 - 1 / pow(10, 16)
	elif valeur <= 0:
		valeur = 1 / pow(10, 16)
	return -log(1 / valeur - 1)

def calculeGrandientNeuronne(n, m):
	somme = 0
	if n == 2:
		if neuronne2Gradient[m] == None:
			neuronne2Gradient[m] = 0
			for i in range(len(listeNeuronneCache2)):
				neuronne2Gradient[m] += poids2[m][i].valeur * sinusoideDerivee(inverseSinusoide(listeNeuronneCache2[i])) * calculeGrandientNeuronne(3, i)
		somme += neuronne2Gradient[m]
	if n == 3:
		if neuronne3Gradient[m] == None:
			neuronne3Gradient[m] = 0
			for i in range(len(listeNeuronneSortie)):
				neuronne3Gradient[m] += poids3[m][i].valeur * sinusoideDerivee(inverseSinusoide(listeNeuronneSortie[i])) * 2 * (listeNeuronneSortie[i] - listeNeuronneReussi[i])
		somme += neuronne3Gradient[m]
	return somme

def calculeGrandientNeuronne2(n, m):
	somme = 0
	if n == 2:
		for i in range(len(listeNeuronneCache2)):
			somme += poids2[m][i].valeur * sinusoideDerivee(inverseSinusoide(listeNeuronneCache2[i])) * calculeGrandientNeuronne(3, i)
	if n == 3:
		for i in range(len(listeNeuronneSortie)):
			somme += poids3[m][i].valeur * sinusoideDerivee(inverseSinusoide(listeNeuronneSortie[i])) * 2 * (listeNeuronneSortie[i] - listeNeuronneReussi[i])
	return somme

def calculeGradientBias(n):
	if n == 0:
		for i in range(1, 4):
			calculeGradientBias(i)
	if n == 1:
		for i in range(len(bias1)):
			bias1Gradient[i] += sinusoideDerivee(inverseSinusoide(listeNeuronneCache1[i])) * calculeGrandientNeuronne(2, i) / len(listeImage)
	if n == 2:
		for i in range(len(bias2)):
			bias2Gradient[i] += sinusoideDerivee(inverseSinusoide(listeNeuronneCache2[i])) * calculeGrandientNeuronne(3, i) / len(listeImage)
	if n == 3:
		for i in range(len(bias3)):
			bias3Gradient[i] += sinusoideDerivee(inverseSinusoide(listeNeuronneSortie[i])) * 2 * (listeNeuronneSortie[i] - listeNeuronneReussi[i]) / len(listeImage)

def changeBias(liste):
	for i in range(len(liste) // 2):
		for j in range(len(liste[i])):
			liste[i][j].valeurAncienne = liste[i][j].valeur
			liste[i][j].valeur -= 1 * liste[i + len(liste) // 2][j]
	return liste[0], liste[1], liste[2]

def calculeGradientPoids(n):
	if n == 0:
		for i in range(1, 4):
			calculeGradientPoids(i)
	if n == 1:
		for i in range(len(poids1)):
			for j in range(len(poids1[i])):
				poids1Gradient[i][j] += listeNeuronneEntree[i] * sinusoideDerivee(inverseSinusoide(listeNeuronneCache1[j])) * calculeGrandientNeuronne(2, j)
	if n == 2:
		for i in range(len(poids2)):
			for j in range(len(poids2[i])):
				poids2Gradient[i][j] += listeNeuronneCache1[i] * sinusoideDerivee(inverseSinusoide(listeNeuronneCache2[j])) * calculeGrandientNeuronne(3, j)
	if n == 3:
		for i in range(len(poids3)):
			for j in range(len(poids3[i])):
				poids3Gradient[i][j] += listeNeuronneCache2[i] * sinusoideDerivee(inverseSinusoide(listeNeuronneSortie[j])) * 2 * (listeNeuronneSortie[j] - listeNeuronneReussi[j]) / len(listeImage)

def changePoids(liste):
	for i in range(len(liste) // 2):
		for j in range(len(liste[i])):
			for k in range(len(liste[i][j])):
				liste[i][j][k].valeurAncienne = liste[i][j][k].valeur
				liste[i][j][k].valeur -= 1 * liste[i + len(liste) // 2][j][k]
	return liste[0], liste[1], liste[2]

# Importation des données

f = open('liste-poids-bias.txt', 'r')
lignes = f.read().split('\n')

poids1 = lignes[0].split(';')
for i in range(len(poids1)):
	poids1[i] = poids1[i].split(',')
	for j in range(len(poids1[i])):
		poids1[i][j] = Liaison(float(poids1[i][j]), 0, i, j)

poids2 = lignes[1].split(';')
for i in range(len(poids2)):
	poids2[i] = poids2[i].split(',')
	for j in range(len(poids2[i])):
		poids2[i][j] = Liaison(float(poids2[i][j]), 1, i, j)

poids3 = lignes[2].split(';')
for i in range(len(poids3)):
	poids3[i] = poids3[i].split(',')
	for j in range(len(poids3[i])):
		poids3[i][j] = Liaison(float(poids3[i][j]), 2, i, j)

bias1 = lignes[3].split(',')
for i in range(len(bias1)):
	bias1[i] = Neuronne(float(bias1[i]), 0, i)

bias2 = lignes[4].split(',')
for i in range(len(bias2)):
	bias2[i] = Neuronne(float(bias2[i]), 1, i)

bias3 = lignes[5].split(',')
for i in range(len(bias3)):
	bias3[i] = Neuronne(float(bias3[i]), 2, i)

f.close()

# Affichage du réseau de neuronne

pygame.display.init()
fenetre = pygame.display.set_mode((1080, 607))
fenetre.fill([0, 0, 0])
pygame.font.init()
myfont = pygame.font.SysFont('Calibri', 20)
myfont2 = pygame.font.SysFont('Calibri', 60)
myfont3 = pygame.font.SysFont('Calibri', 20, bold=True)

def sinusoTriple(valeur):
	if valeur * -3 >= 709:
		valeur = -236
	return 1 / (1 + exp(-3 * valeur))

def renderHaut():
	pygame.draw.rect(fenetre, 3 * [128], (0, 0, 1080, 112))
	for i in range(784):
		pygame.draw.rect(fenetre, 3 * [listeNeuronneEntree[i] * 255], (115 + 3 * (i % 28), 14 + 3 * (i // 28), 3, 3))
	pygame.draw.lines(fenetre, 3 * [255], False, [(289, 46), (299, 56), (249, 56), (299, 56), (289, 66)], width=3)
	maxi = (listeNeuronneSortie[0], 0)
	for i in range(len(listeNeuronneSortie)):
		if listeNeuronneSortie[i] > maxi[0]:
			maxi = (listeNeuronneSortie[i], i)
	if listeNeuronneReussi[maxi[1]] == 1:
		fenetre.blit(myfont2.render(str(maxi[1]) + '  Oui !', False, (255, 255, 255)), (319, 26))
	else:
		fenetre.blit(myfont2.render(str(maxi[1]) + '  Non !', False, (255, 255, 255)), (319, 26))
	fenetre.blit(myfont.render('Coût moyen :', False, (255, 255, 255)), (610, 36))
	fenetre.blit(myfont.render(str(cout / tente), False, (255, 255, 255)), (585, 56))
	fenetre.blit(myfont.render('Réussi :', False, (255, 255, 255)), (845, 36))
	fenetre.blit(myfont.render(str(reussi) + '/' + str(tente) + ' -> ' + str(round(100 * reussi / tente, 2)) + ' %', False, (255, 255, 255)), (825, 56))

def renderChangement():
	fenetre.blit(myfont.render('Résultat attendu :', False, (255, 255, 255)), (830, 130))
	for i in range(19):
		if i % 2 == 0:
			for j in range(16):
				pygame.draw.line(fenetre, [-511 * min(0, sinusoide(2000 * -poids1Gradient[28 * i + 182][j]) - 0.5), 0, 511 * max(0, sinusoide(2000 * -poids1Gradient[28 * i + 182][j]) - 0.5)], (180, 126 + i * 26), (360, 135 + j * 30))
	for i in range(16):
		for j in range(16):
			pygame.draw.line(fenetre, [-511 * min(0, sinusoide(100 * -poids2Gradient[i][j]) - 0.5), 0, 511 * max(0, sinusoide(100 * -poids2Gradient[i][j]) - 0.5)], (360, 135 + i * 30), (540, 135 + j * 30))
		for j in range(10):
			pygame.draw.line(fenetre, [-511 * min(0, sinusoide(2000 * -poids3Gradient[i][j]) - 0.5), 0, 511 * max(0, sinusoide(2000 * -poids3Gradient[i][j]) - 0.5)], (540, 135 + i * 30), (720, 181 + 40 * j))
	
	for i in range(19):
		if i % 2 == 0:
			pygame.draw.circle(fenetre, 3 * [255], [180, 126 + i * 26], 10)
			pygame.draw.circle(fenetre, 3 * [listeNeuronneEntree[28 * i + 182] * 255], [180, 126 + i * 26], 9)
		else:
			for j in range(3):
				pygame.draw.circle(fenetre, 3 * [255], [174 + j * 6, 126 + i * 26], 2)
	for i in range(16):
		pygame.draw.circle(fenetre, 3 * [255], [360, 135 + i * 30], 11)
		pygame.draw.circle(fenetre, 3 * [255], [540, 135 + i * 30], 11)
		pygame.draw.circle(fenetre, [-511 * min(0, sinusoide(10000 * -bias1Gradient[i]) - 0.5), 0, 511 * max(0, sinusoide(10000 * bias1Gradient[i]) - 0.5)], [360, 135 + i * 30], 10)
		pygame.draw.circle(fenetre, [-511 * min(0, sinusoide(1000 * -bias2Gradient[i]) - 0.5), 0, 511 * max(0, sinusoide(1000 * bias2Gradient[i]) - 0.5)], [540, 135 + i * 30], 10)
	for i in range(10):
		pygame.draw.circle(fenetre, 3 * [255], [720, 181 + 40 * i], 16)
		pygame.draw.circle(fenetre, 3 * [255], [900, 181 + 40 * i], 16)
		pygame.draw.circle(fenetre, [-511 * min(0, sinusoide(500 * -bias3Gradient[i]) - 0.5), 0, 511 * max(0, sinusoide(500 * bias3Gradient[i]) - 0.5)], [720, 181 + 40 * i], 15)
		pygame.draw.circle(fenetre, 3 * [listeNeuronneReussi[i] * 255], [900, 181 + 40 * i], 15)
		if listeNeuronneReussi[i] == 1:
			fenetre.blit(myfont3.render(str(i), False, (0, 0, 0)), (896, 173 + 40 * i))
		else:
			fenetre.blit(myfont3.render(str(i), False, (255, 255, 255)), (896, 173 + 40 * i))
	renderHaut()

def renderReseau():
	fenetre.blit(myfont.render('Résultat attendu :', False, (255, 255, 255)), (830, 130))
	for i in range(19):
		if i % 2 == 0:
			for j in range(16):
				pygame.draw.line(fenetre, 3 * [sinusoTriple(poids1[28 * i + 182][j].valeur) * 255], (180, 126 + i * 26), (360, 135 + j * 30))
	for i in range(16):
		for j in range(16):
			pygame.draw.line(fenetre, 3 * [sinusoTriple(poids2[i][j].valeur) * 255], (360, 135 + i * 30), (540, 135 + j * 30))
		for j in range(10):
			pygame.draw.line(fenetre, 3 * [sinusoTriple(poids3[i][j].valeur) * 255], (540, 135 + i * 30), (720, 181 + 40 * j))

	for i in range(19):
		if i % 2 == 0:
			pygame.draw.circle(fenetre, 3 * [255], [180, 126 + i * 26], 10)
			pygame.draw.circle(fenetre, 3 * [listeNeuronneEntree[28 * i + 182] * 255], [180, 126 + i * 26], 9)
		else:
			for j in range(3):
				pygame.draw.circle(fenetre, 3 * [255], [174 + j * 6, 126 + i * 26], 2)
	for i in range(16):
		pygame.draw.circle(fenetre, 3 * [255], [360, 135 + i * 30], 11)
		pygame.draw.circle(fenetre, 3 * [255], [540, 135 + i * 30], 11)
		pygame.draw.circle(fenetre, 3 * [listeNeuronneCache1[i] * 255], [360, 135 + i * 30], 10)
		pygame.draw.circle(fenetre, 3 * [listeNeuronneCache2[i] * 255], [540, 135 + i * 30], 10)
	for i in range(10):
		pygame.draw.circle(fenetre, 3 * [255], [720, 181 + 40 * i], 16)
		pygame.draw.circle(fenetre, 3 * [255], [900, 181 + 40 * i], 16)
		pygame.draw.circle(fenetre, 3 * [listeNeuronneSortie[i] * 255], [720, 181 + 40 * i], 15)
		pygame.draw.circle(fenetre, 3 * [listeNeuronneReussi[i] * 255], [900, 181 + 40 * i], 15)
		if listeNeuronneReussi[i] == 1:
			fenetre.blit(myfont3.render(str(i), False, (0, 0, 0)), (896, 173 + 40 * i))
		else:
			fenetre.blit(myfont3.render(str(i), False, (255, 255, 255)), (896, 173 + 40 * i))
	renderHaut()

# Sauvegarde des changements

def enregistre():
	f = open('liste-poids-bias.txt', 'w')

	# Poids 1 :

	for i in range(783):
		for j in range(15):
			f.write(str(poids1[i][j].valeur) + ',')
		f.write(str(poids1[i][15].valeur) + ';')
	for j in range(15):
		f.write(str(poids1[783][j].valeur) + ',')
	f.write(str(poids1[783][15].valeur) + '\n')

	# Poids 2 :

	for i in range(15):
		for j in range(15):
			f.write(str(poids2[i][j].valeur) + ',')
		f.write(str(poids2[i][15].valeur) + ';')
	for j in range(15):
		f.write(str(poids2[15][j].valeur) + ',')
	f.write(str(poids2[15][15].valeur) + '\n')

	# Poids 3 :

	for i in range(15):
		for j in range(9):
			f.write(str(poids3[i][j].valeur) + ',')
		f.write(str(poids3[i][9].valeur) + ';')
	for j in range(9):
		f.write(str(poids3[15][j].valeur) + ',')
	f.write(str(poids3[15][9].valeur) + '\n')

	# Bias 1 :

	for i in range(15):
		f.write(str(bias1[i].valeur) + ',')
	f.write(str(bias1[15].valeur) + '\n')

	# Bias 2 :

	for i in range(15):
		f.write(str(bias2[i].valeur) + ',')
	f.write(str(bias2[15].valeur) + '\n')

	# Bias 3 :

	for i in range(9):
		f.write(str(bias3[i].valeur) + ',')
	f.write(str(bias3[9].valeur))

	f.close()

# Boucle infinie YOUPI

nombreBoucle = 0
fonctionRender = [renderReseau, renderChangement]
while True:
	cout = 0
	reussi = 0
	tente = 0
	bias1Gradient = 16 * [0]
	bias2Gradient = 16 * [0]
	bias3Gradient = 10 * [0]
	poids1Gradient = [16 * [0] for i in range(784)]
	poids2Gradient = [16 * [0] for i in range(16)]
	poids3Gradient = [10 * [0] for i in range(16)]

	listeImage = []
	for i in range(100):
		listeImage.append(data[randint(0, len(data) - 1)])

	for image in listeImage:
		neuronne2Gradient = 16 * [None]
		neuronne3Gradient = 16 * [None]
		listeNeuronneEntree = neuronneEntre(image)
		listeNeuronneCache1 = multiplieMatrice(listeNeuronneEntree, poids1, bias1)
		listeNeuronneCache2 = multiplieMatrice(listeNeuronneCache1, poids2, bias2)
		listeNeuronneSortie = multiplieMatrice(listeNeuronneCache2, poids3, bias3)
		listeNeuronneReussi = [0] * len(listeNeuronneSortie)
		listeNeuronneReussi[image[1]] = 1

		cout, tente, reussi = calcluleStat(cout, tente, reussi, listeNeuronneSortie, listeNeuronneReussi)

		calculeGradientBias(0)
		calculeGradientPoids(0)

		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.display.quit()
				sys.exit()
		pygame.display.update()

	fonctionRender[nombreBoucle % 2]()
	nombreBoucle += 1
	bias1, bias2, bias3 = changeBias([bias1, bias2, bias3, bias1Gradient, bias2Gradient, bias3Gradient])
	poids1, poids2, poids3 = changePoids([poids1, poids2, poids3, poids1Gradient, poids2Gradient, poids3Gradient])
	enregistre()